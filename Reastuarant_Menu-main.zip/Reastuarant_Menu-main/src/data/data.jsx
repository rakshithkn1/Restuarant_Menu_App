import choola from "../assets/choola.jpeg";
import dosa from "../assets/dosa.jpeg";
import butter from "../assets/butter.jpeg";
import palav from "../assets/palav.jpeg";
import idli from "../assets/idli.jpeg";
import lemon from "../assets/lemon.jpg";

export const Data = [{
    name: "samosa" ,
    image: choola ,
    price: 150,
},
{
    name: "masala",
    image: dosa,
    price: 100,
},
{
    name: "Butter Panner",
    image:butter,
    price:120,
},
{
    name:"palav",
    image:palav,
    price:60,
},
{
    name:"idli",
    image:idli,
    price:50,
},
{
    name:"lemon rice",
    image:lemon,
    price:40,
}
]